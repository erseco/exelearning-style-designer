/* Write your JavaScript code here.
   You can use as reference the JavaScript code used in other eXeLearning styles.
   Remember that you can make use of jQuery.
   If you have questions, consult:
   https://github.com/exelearning/exelearning/blob/main/doc/development/styles.md
*/
